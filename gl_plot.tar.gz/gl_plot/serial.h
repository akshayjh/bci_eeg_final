#ifndef SERIAL_H_INCLUDED
#define SERIAL_H_INCLUDED


bool openSerial();
void closeSerial();

unsigned int readSerialValue();

#endif // SERIAL_H_INCLUDED
